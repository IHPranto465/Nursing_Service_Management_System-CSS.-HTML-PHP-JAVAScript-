<?php
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Manager Registration</title>

	
	<body>
	<table  align='center'>
	<h1 align='center'>Manager Registration Form</h1>
	                    
		<h4 align='center'>
			<?php
			if(!empty($_SESSION['message']))
			{
				echo $_SESSION['message'];
			}
		 	?>    
		</h4>               
        <form action="managerControl.php" method="post">
		
</head>
<body>
    <div class="topSection">
        <h1 class='topTitle'>Welcome to the Nursing system</h1>
        <br>
        <a href="aboutUs.php" class='aboutPbl'>About Our Service System</a><br>
        <br>
        <a href="contactUs.php" class='contactUs'>Contact Us</a><br>
        <a href="signupPage.php" id="login"><h3>SignUp</h3></a>
        <a href="manager_login.php" id="login"><h3>Login</h3></a>
    </div>
    <div class='navbar'>
        <div class='navCont'>
            <a href="homePage.php" id="nav-cont">Home</a><br>
            <br>
            <a href="branches.php" id="nav-cont">Branches</a>
            <br>
        </div>
    </div>
	

		
					
				<tr>
					<td>Full Name :</td>
					<td><input name="fname" type="text"> 
						<?php 
							if(!empty($_SESSION['name_error']))
							{
								echo $_SESSION['name_error'];
							}
						?>
					</td>
				</tr>
				<tr>
					<td>Email :</td>
					<td><input type="email" name="email"> 
					<?php 
						if(!empty($_SESSION['email_error']))
						{
							echo $_SESSION['email_error'];
						}
					 ?>
					</td>
				</tr>
				<tr>
					<td>Password :</td>
					<td><input type="password" name="password"> 
					 <?php
					 	if(!empty($_SESSION['pass_error']))
						{
						 	echo $_SESSION['pass_error'];
						}
					 ?>
					</td>
				</tr>
				<tr>
					<td>Contact :</td>
					<td><input type="contact" name="contact"> 
					 <?php  
						if(!empty($_SESSION['contact_error']))
						{
							echo $_SESSION['contact_error'];
						} 
					 ?>
					</td>
				</tr>
                <tr>
	                <td>Office ID :</td>
					<td><input type="nid" name="nid">  
					<?php
						if(!empty($_SESSION['Nid_error']))
						{
							echo $_SESSION['Nid_error'];
						}
					 ?>
					</td>
				</tr>
				
				
				<tr>
					<td>Gender :</td>
					<td>
						<input type="radio" id="male" name="gender" value="Male"> Male
						<input type="radio" id="female" name="gender" value="Female"> Female						
						<?php
	                        if(!empty($_SESSION['Gender_error']))
							{
							 	echo $_SESSION['Gender_error'];
							} 
                         ?>
					</td>
				</tr>
           
                <tr>
					<td>Present Address:</td>
					<td>
						<textarea rows="4" cols="40" name="Address"></textarea> 
						<?php 
							if(!empty($_SESSION['add_error']))
							{
							 	echo $_SESSION['add_error'];
							}
						?>
					</td>
				</tr>
            	<br>
        		<tr>
        			<td align='center'><input type="submit" name="submit" value="Submit"></td>
        		</tr>
				<tr>
					<td align='center'><br>
	                Already have an account?
					<a href="manager_login.php">
						<h3>Log-in</h3>
					</a>				
            	</tr>
			</table>
		</form>
	</body>
</head>
</html>

<?php
	unset($_SESSION['name_error']);
    unset($_SESSION['mail_error']);
    unset($_SESSION['add_error']);
    unset($_SESSION['cont_error']);
    unset($_SESSION['pass_error']);
    unset($_SESSION['Gender_error']);
    unset($_SESSION['Nid_error']);
    unset($_SESSION['message']);
?>