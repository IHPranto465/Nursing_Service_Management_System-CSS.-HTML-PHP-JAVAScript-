<?php
    session_start();

    
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My Profile</title>
        
    </head>
    <body>
    <h1 >My Profile</h1>   <br>                    
        <form action="act2.php" method="post">
            <table  >   
    
            <h2>My information</h2>
            <a href="act2.php">data here</a><br> </h2>
    
            <a href="updatedata.php"><h2>Update</h3><br>       
            <br>         
            <td><a href="deletedata.php"><h2>Delete</h3><br>
            <br>
			<a href="logout.php"><h2>Logout</h3><br>
            
    
           

                    
        </form>
    </body>
</html>