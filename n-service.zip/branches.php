<!DOCTYPE html>
<html lang="en">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to the Nursing Service System</title>
 
</head>
    <div class="topSection">
        <h1 class='topTitle'>Nursing Service System</h1>
        <h2 class='slogan'>- the service you can trust</h2>
        <a href="aboutUs.php" class='aboutPbl'>About us</a><br>
        <a href="contactUs.php" class='contactUs'>Contact Us</a><br>
    </div>
    <div class='navbar'>
        <div class='navCont'>
            <a href="homePage.php" id="nav-cont">Home</a><br>
            <a href="branches.php" id="nav-cont">Branches</a><br>
        </div>
       
        <br><br><br><br> 
        <div class="empReg">
            <h2>Motijheel Branch</h2>
            <p>Address: <br><br> Plot # 9/i, Motijheel C/A, Dhaka City Corporation </p><br><br><br><br>     
      </div> 
        <div class="cusReg">
            <h2>Khilgaon Branch</h2>
            <p>Address: <br><br>  934/C, Khilgaon, Shahid Baki Rd, 1219 Dhaka </p><br><br><br><br>   

            <div class="cusReg">
            <h2>Kuril Branch</h2>
            <p>Address: <br><br> Shimul Trade Centre, Ka-​86/1, Kuril Bishwaroad </p><br><br><br><br>  
        </div>  
    <footer class='footer'>
    Nursing Service System
    </footer>

    </div>   
</body>
</html>