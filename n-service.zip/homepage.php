<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome to Nursing Service System</title>
   
    

</head>
<body>
    <div class="topSection">
        <h1 class='topTitle'>Welcome to the Nursing system</h1>
        <h2 class='slogan'>- the service you can trust</h2>
        <br>
        <a href="aboutUs.php" class='aboutPbl'>About Our Service System</a><br>
        <br>
        <a href="contactUs.php" class='contactUs'>Contact Us</a><br>
        <a href="signupPage.php" id="login"><h3>SignUp</h3></a>
        <a href="manager_login.php" id="login"><h3>Login</h3></a>
    </div>
    <div class='navbar'>
        <div class='navCont'>
            <a href="homePage.php" id="nav-cont">Home</a><br>
            <br>
            <a href="branches.php" id="nav-cont">Branches</a>
            <br>
        </div>
    </div>
      <div class = "nurse1">
        <img src="../resources1/nurse1.jpg" alt="nurse1" height="1200px" width="1600px" style="padding-top: -200px">
    </div>


    </footer>  
</body>
</html>