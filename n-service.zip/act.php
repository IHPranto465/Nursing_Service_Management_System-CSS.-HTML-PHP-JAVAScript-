<?php
    session_start();

    
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My details</title>
        
    </head>
    <body>
    <h1 >My profile</h1>   <br>                    
        <form action="act2.php" method="post">
            <table  >   
            <tr>
            <td><h2>My details is :</h2></td>
            <td><a href="act2.php">here</a><br> </h2>
            </tr>
                                
           
        
                    
        </form>
    </body>
</html>