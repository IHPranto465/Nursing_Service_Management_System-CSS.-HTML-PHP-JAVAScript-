<?php
session_start();
$data = file_get_contents("manager.json");
$mydata = json_decode($data);


foreach($mydata as $myobject)
{
foreach($myobject as $key=>$value)
{
   
   echo "your ".$key." is ".$value."<br>";
   header("managerDetails.php"); 

} 

}

?>