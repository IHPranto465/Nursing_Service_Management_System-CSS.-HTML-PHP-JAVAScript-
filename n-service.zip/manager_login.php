<?php
	session_start();

	if(isset($_SESSION['username'])|| isset($_COOKIE['username']))
    {
        header("Location:managerDetails.php");
    }
    else{
    	$data = file_get_contents('manager.json');
        $data_array = json_decode($data, true);
        
    
        if (isset($_POST['submit'])) {
        	$email=$_POST['email'];
        	$pass=$_POST['password'];
        	foreach ($data_array as $key => $value) {
        		if($value['email']==$email)
        		{
        			if($value['password']==$pass)
        			{
	    				 $_SESSION['username']=$value['name'];
	    				 setcookie('username', $value['name'], time() + (86400 * 5), "/");
	               		 header("Location:managerDetails.php"); 
        			}
        		}
        	}
        	
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
</head>
<body>
    <div class="topSection">
        <h1 class='topTitle'>Welcome to the Nursing system</h1>
        <h2 class='slogan'>- the service you can trust</h2>
        <br>
        <a href="aboutUs.php" class='aboutPbl'>About Our Service System</a><br>
        <br>
        <a href="contactUs.php" class='contactUs'>Contact Us</a><br>
        <a href="signupPage.php" id="login"><h3>SignUp</h3></a>
        <a href="manager_login.php" id="login"><h3>Login</h3></a>
    </div>
    <div class='navbar'>
        <div class='navCont'>
            <a href="homePage.php" id="nav-cont">Home</a><br>
            <br>
            <a href="branches.php" id="nav-cont">Branches</a>
            <br>
        </div>
    </div>
		
	<head>
	<fieldset class="cl">

		<title>Manager Login</title>
		
	</head>
	<body>
	<h1 align='center'>Manager Login Form</h1>	                    
		<form action="" method="post">
			<table  align='center'>	
			<tr>
			<td>Email :</td>
			<td><input type="email" name="email"> 
			</tr>
			<tr>
			<td>Password :</td>
			<td><input type="password" name="password"> 
			</tr>					
			<tr>
			<tr>
			<tr><td align='center'><br><input type="submit" name="submit" value="Login"></td></tr>
        
            <tr><td align='center'><br>
			Don't have an account yet?
				<a href="managerRegistration.php">
					<h3>Sign Up</h3>
				</a>								
        	</tr>			
		</form>
	</body>
</html>