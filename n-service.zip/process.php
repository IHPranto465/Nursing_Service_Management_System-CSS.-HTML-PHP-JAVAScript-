<?php
session_start();
$name_error = "";
$cont_error = "";
 $prob_error= "";
 $time_error="";
 $payment_error="";
$serial_error="";
if (isset($_POST['submit']))
{

    if (empty($_POST["fname"]))
    {
        $name_error = "You must enter name";

    }
    else
    {
        if((strlen($_POST["fname"]) < 3))
        $name_error = "Name must be more than 3 characters";
    }

    if (empty($_POST["time"]))
    {
        $time_error = "Please provide time";
    }
    if (empty($_POST["serial"]))
    {
        $serial_error = "Please Enter a serial Number";
    }
    if (empty($_POST["payment"]))
    {
        $payment_error = "";
    }
    
    if (empty($_POST["contact"]))
    {
        $cont_error = "Enter Your Contact Nubmer";

    }
    else
    {
        if((strlen($_POST["contact"]) < 3))
        {
            $cont_error = "Contact Number must be more than 3 characters";
        }
    }

   
if($name_error = "" && $cont_error = "" && $prob_error= "" && $time_error="" && $payment_error="" && $serial_error="")
{
    $formdata = array(
    'name'=> $_POST['fname'],
    'contact'=> $_POST['contact'],
    'Serial' => $_POST['serial'],
    'Time'=> $_POST['time'],
    'Payment'=> $_POST['payment'],
    
    'Problem' => $_POST['prob'],
    );
    $existingdata = file_get_contents('Details.json');
    $tempJSONdata = json_decode($existingdata, true);
    $tempJSONdata[] =$formdata;
    $jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);

    if(file_put_contents("Details.json", $jsondata)){
        $_SESSION['message']='Data successfully saved.';
       
        header("Location:PatientDetails.php");
    } else{
        $_SESSION['message']="No data saved";
       
        header("Location:PatientDetails.php");
    }  
}
    else{
        $_SESSION['name_error']=$name_error;
        $_SESSION['prob_error']=$prob_error;
        $_SESSION['time_error']=$time_error;
        $_SESSION['cont_error']=$cont_error;
        $_SESSION['payment_error']=$payment_error;
        $_SESSION['serial_error']=$serial_error;
        header("Location:PatientDetails.php");    
    
    }
}
?>