<?php
    session_start();

    
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>update the data</title>
        
    </head>
    <body>
    <h1 >update The data </h1>   <br>                    
        <form action="update.php" method="post">
            <table  >   
            <tr>
            <td>  Give your office ID <input type="text" name="nid"  > :</td>
            

            </tr>
                                
            <tr>
            <tr>
            <tr><td align='center'><br><input type="submit" name="submit" value="Update"></td></tr>
        
                    
        </form>
    </body>
</html>