<?php



echo "<h1>Nurse  deleted Successfully</h1>";

echo "<a href='login.php'><button type='button'>Go Back To login</button></a>";




?>