<?php



echo "<h1> Person deleted Successfully</h1>";

echo "<a href='login.php'><button type='button'>Go Back To login</button></a>";




?>