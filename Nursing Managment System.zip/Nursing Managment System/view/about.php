
<!DOCTYPE html>
<html lang="en">
<head>
	<title align="center" >About Us</title>
	<link rel="stylesheet" href="../css/home.css">
</head>
<body>
<ul>
        <li><a href="Home.php">Home Page</a></li>
        <li><a href="contact.php">About</a></li>
        
            </ul>
        <h1 align='center' style="font-family:Poor Richard">At A Glance</h1>
        <h2 align='center' style="font-family:Poor Richard">Nursing Managment System</h2>
        <h2 align='center' style="font-family:Poor Richard">We provide nurse to a patient by taking money. This is a social work also.</h2>
       <h2 align='center' style="font-family:Poor Richard">Contact us to hire a nurse whenever you need!!!</h2>
    </body>
   
          
</html>