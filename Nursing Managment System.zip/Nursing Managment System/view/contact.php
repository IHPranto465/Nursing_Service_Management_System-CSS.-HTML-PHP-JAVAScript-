
<!DOCTYPE html>
<html lang="en">
<head>
	<title align="center" > My Contact</title>
	<link rel="stylesheet" href="../css/home.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("button").click(function(){
    $("h2").hide();
  });
});
</script>
</head>
    <body>
    <ul>
        <li><a href="Home.php">Home Page</a></li>
        <li><a href="about.php">About</a></li>
        
            </ul>
    <div>
        <h1>Contact With Us Now!</h1>
        <h2 >Adress: House No .TA 110/1, Gulshan Link Road, Dhaka 1212</h2>
        <h2 >Mobile: +880 1432-1754121</h2>
        <h2 >Email: nursingservice@gmail.com</h2> 
    <br>
    <h2 >Adress: 1217, Kuril,biswa Road, Dhaka</h2>
        <h2 >Mobile: +880 1714-595773</h2>
        <h2 >Email: nursingmanagment@gmail.com</h2>
        <br>
    <h2 >Adress: House-17, Road-1, Block-B, Dhaka:1216</h2>
        <h2 >Mobile: +880 1715-067370</h2>
       
    </div>
    </body>
    <button>Click me to hide my contact</button>
    
</html>